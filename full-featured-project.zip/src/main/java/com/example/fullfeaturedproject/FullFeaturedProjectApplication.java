package com.example.fullfeaturedproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main class for Full Featured Project
 * A project showcasing all new features
 */
@SpringBootApplication
public class FullFeaturedProjectApplication {
    public static void main(String[] args) {
        SpringApplication.run(FullFeaturedProjectApplication.class, args);
    }
}